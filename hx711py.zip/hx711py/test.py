f = open("data.txt","a")
f.write("Now the file has more content! \n")
f.close()

#open and read the file after the appending:
f = open("data.txt", "r")
print(f.read())