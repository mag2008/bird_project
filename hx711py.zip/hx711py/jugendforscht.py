import time
import sys
import RPi.GPIO as GPIO
from hx711v0_5_1 import HX711
import statistics
import cv2
from datetime import datetime
import threading 

#initialise forcesensor
hx = HX711(23, 24)

hx.setReadingFormat("MSB", "MSB")

print("[INFO] Automatically setting the offset.")
hx.autosetOffset()
#initialize the camera
cap = cv2.VideoCapture(0)

# Check if the camera is opened successfully
if not cap.isOpened():
    print("Error: Cannot access the camera")
    exit()
else:
    print("opened camera successfully")
    


class file:
    def __init__(self,file_name):
        self.event = threading.Event()
        self.file_name = file_name
    def write(self, data):
        self.f_data = open(self.file_name,"a")
        self.f_data.write(data)
        self.f_data.close()

file_for_data = file("data.txt") 


# Get the mass values in centigrams


# Calculate the median mass of five data points 
class data:
    def __init__(self,counter,debugging=False):
        global file_for_data
        if debugging:
            self.error_debugging = True
        else:
            self.error_debugging = False
        
        self.counter = counter
        self.mass_list = []
        self.return_string = ""
    def return_offset_value(self):
        
        self.rawBytes = hx.getRawBytes()
        self.longWithOffsetValue = hx.rawBytesToLongWithOffset(self.rawBytes)
        return self.longWithOffsetValue
    def calc_data(self):
        self.mass_list = []
        for _ in range(self.counter):
            self.mass_list.append(self.return_offset_value())
        self.median_value = statistics.median(self.mass_list)
        if self.error_debugging:
            print("self.mass_list is:" +self.mass_list)
            print("self.median_value is:" +self.median_value)
    def return_median_value(self):
        self.calc_data()
        return self.median_value
    def return_data(self):
        self.calc_data()
        return self.mass_list
    def save_data(self,null_data, date):
        self.return_string += str(date) + " "
        for i in range(self.counter):
            self.return_string += str(self.mass_list[i]).zfill(6) + " ,"
        self.return_string += str(null_data) + "\n"
        file_for_data.write(self.return_string)
        if self.error_debugging:
            print("self.return_string is:" +self.return_string)

d = data(5)
# determine the mass of meisenknoedel without bird
null_value = d.return_median_value()

#Wait for the mass to change and take a video when it increases by >500 centigrams
while True:
        try:
            #take 5 samples because there are sometimes weird values
            time.sleep(0.2)
            
            current_mass = d.return_median_value()
            #print(current_mass)
            if current_mass > (null_value + 500):
                
                print("bird detected!")
                
                
                # Get the current date and time
                current_time = str(datetime.now().strftime('%Y-%m-%d-%H-%M-%S'))
                d.save_data(null_value,current_time)

                # Create a filename based on the current time
                video_filename = "/home/pi/Videos/"+current_time+".avi"

                fourcc = cv2.VideoWriter_fourcc(*'XVID')  # Codec for .avi files
                out = cv2.VideoWriter(video_filename, fourcc, 30.0, (640, 480))

                end_time = time.time() + 5
                while time.time() < end_time:
                    ret, frame = cap.read()  # Capture each frame
                    if not ret:
                        print("Error: Can't receive frame (stream end?). Exiting ...")
                        break

                    # Write the frame to the output file
                    out.write(frame)
                print("video captured")
                null_value = d.return_median_value()
                out.release()#finish video
            #check if the mass of the meisenknoedel has changed slightly (by more than 100 centigrams)
            elif current_mass > (null_value + 100) or current_mass < (null_value - 100):
                null_value = d.return_median_value()
                print("changed null_value to " + str(null_value))
        except (KeyboardInterrupt, SystemExit):            
            GPIO.cleanup()
            print("[INFO] 'KeyboardInterrupt Exception' detected. Cleaning and exiting...")
            sys.exit()
        except Exception as e:
            try :
                f_error = open("error.txt","a")
                f_error.write(e)
                f_error.close()
                print("error occured: \n" + str(e))
            except:
                print("error occured: \n" + str(e) + "\n could not open file")
